#ifndef BANK_H
#define BANK_H


class Bank
{
public:
    Bank();
};

#endif // BANK_H
